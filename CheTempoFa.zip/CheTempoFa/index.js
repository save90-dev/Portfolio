/*ENVIRONMENT VARIABLES*/

const APIkey = process.env.API_key



/*GEOLOCATION*/
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("La Geolocalizzazione non è supportata dal tuo Browser. Inserisci manualmente il nome della città");
    }
}

async function showPosition(position) {

    latitude = position.coords.latitude;
    longitude = position.coords.longitude;

    await fetch('https://nominatim.openstreetmap.org/reverse?format=geojson&lat=' + latitude + '&lon=' + longitude + '')
        .then((response) => response.json())
        .then((data) => {
            if ((data['features'][0]['properties']['address']['town']) == null) {

                if ((data['features'][0]['properties']['address']['city']) == null) {

                    document.getElementById('name').innerHTML = data['features'][0]['properties']['address']['village']
                } else {
                    document.getElementById('name').innerHTML = data['features'][0]['properties']['address']['city']
                }
            } else {
                document.getElementById('name').innerHTML = data['features'][0]['properties']['address']['town']
            }
        })

    document.getElementById('display').style.visibility = "visible";

    await fetch('https://api.openweathermap.org/data/2.5/onecall?lat=' + latitude + '&lon=' + longitude + '&appid='+ APIkey +'&lang=IT&units=metric')
        .then(response => response.json())
        .then(data => {

            longDate0 = (new Date((data['daily'][0]['dt']) * 1000));
            month0 = new Intl.DateTimeFormat('it', { month: 'short' }).format(longDate0);
            day0 = new Intl.DateTimeFormat('it', { day: '2-digit' }).format(longDate0);
            console.log(day0 + " " + month0.replace(/^\w/, (c) => c.toUpperCase()));
            console.log(Math.round(data['current']['temp']) + "°");
            console.log(data['current']['weather'][0]['description']);
            console.log(Math.round(data['daily'][0]['temp']['min']) + "°");
            console.log(Math.round(data['daily'][0]['temp']['max']) + "°");

            document.getElementById('day0').innerHTML = day0 + " " + month0;
            document.getElementById('icon0').src = ('http://openweathermap.org/img/wn/' + (data['current']['weather'][0]['icon']).substring(0, 2) + "d" + '@2x.png');
            document.getElementById('desc0').innerHTML = data['current']['weather'][0]['description'];
            document.getElementById('temp0').innerHTML = Math.round(data['current']['temp']) + "°";
            document.getElementById('min0').innerHTML = Math.round(data['daily'][0]['temp']['min']) + "°";
            document.getElementById('max0').innerHTML = Math.round(data['daily'][0]['temp']['max']) + "°";

            console.log('============================');

            for (let i = 1; i < 7; i++) {
                let longDate = (new Date((data['daily'][i]['dt']) * 1000));
                let month = new Intl.DateTimeFormat('it', { month: 'short' }).format(longDate);
                let day = new Intl.DateTimeFormat('it', { day: '2-digit' }).format(longDate);
                console.log(day + " " + month.replace(/^\w/, (c) => c.toUpperCase()));
                console.log(Math.round(data['daily'][i]['temp']['day']) + "°");
                console.log(data['daily'][i]['weather'][0]['description']);
                console.log(Math.round(data['daily'][i]['temp']['min']) + "°");
                console.log(Math.round(data['daily'][i]['temp']['max']) + "°");

                document.getElementById('day' + [i]).innerHTML = day + " " + month;
                document.getElementById('icon' + [i]).src = ('http://openweathermap.org/img/wn/' + (data['daily'][i]['weather'][0]['icon']).substring(0, 2) + "d" + '@2x.png');
                document.getElementById('desc' + [i]).innerHTML = data['daily'][i]['weather'][0]['description'];
                document.getElementById('temp' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['day']) + "°";
                document.getElementById('min' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['min']) + "°";
                document.getElementById('max' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['max']) + "°";

                console.log('============================');

            }
        })
}

async function searchCity() {
    const inputCity = document.getElementById('inputCity');

    if (inputCity.value == "") {
        alert('Devi digitare il nome della città per avviare una ricerca')
    } else {

        let inputCity = document.getElementById('inputCity').value;

        await fetch('https://nominatim.openstreetmap.org/?addressdetails=1&q=' + inputCity + '&format=json')
            .then((response) => response.json())
            .then((data) => {
                console.log(data[0]['lat']);
                console.log(data[0]['lon']);

                lat = data[0]['lat'];
                lon = data[0]['lon'];
            })
            .catch(error => {
                alert("Sei sicuro di aver digitato correttamente il nome della città?");
                window.location.reload();
            })


        await fetch('https://api.openweathermap.org/data/2.5/onecall?lat=' + lat + '&lon=' + lon + '&appid=' + APIkey + '&lang=IT&units=metric')
            .then(response => response.json())
            .then(data => {

                longDate0 = (new Date((data['daily'][0]['dt']) * 1000));
                month0 = new Intl.DateTimeFormat('it', { month: 'short' }).format(longDate0);
                day0 = new Intl.DateTimeFormat('it', { day: '2-digit' }).format(longDate0);
                console.log(day0 + " " + month0.replace(/^\w/, (c) => c.toUpperCase()));
                console.log(Math.round(data['current']['temp']) + "°");
                console.log(data['current']['weather'][0]['description']);
                console.log(Math.round(data['daily'][0]['temp']['min']) + "°");
                console.log(Math.round(data['daily'][0]['temp']['max']) + "°");

                document.getElementById('day0').innerHTML = day0 + " " + month0;
                document.getElementById('icon0').src = ('http://openweathermap.org/img/wn/' + (data['current']['weather'][0]['icon']).substring(0, 2) + "d" + '@2x.png');
                document.getElementById('desc0').innerHTML = data['current']['weather'][0]['description'];
                document.getElementById('temp0').innerHTML = Math.round(data['current']['temp']) + "°";
                document.getElementById('min0').innerHTML = Math.round(data['daily'][0]['temp']['min']) + "°";
                document.getElementById('max0').innerHTML = Math.round(data['daily'][0]['temp']['max']) + "°";


                console.log('============================');

                for (let i = 1; i < 7; i++) {
                    let longDate = (new Date((data['daily'][i]['dt']) * 1000));
                    let month = new Intl.DateTimeFormat('it', { month: 'short' }).format(longDate);
                    let day = new Intl.DateTimeFormat('it', { day: '2-digit' }).format(longDate);
                    console.log(day + " " + month.replace(/^\w/, (c) => c.toUpperCase()));
                    console.log(Math.round(data['daily'][i]['temp']['day']) + "°");
                    console.log(data['daily'][i]['weather'][0]['description']);
                    console.log(Math.round(data['daily'][i]['temp']['min']) + "°");
                    console.log(Math.round(data['daily'][i]['temp']['max']) + "°");

                    document.getElementById('day' + [i]).innerHTML = day + " " + month;
                    document.getElementById('icon' + [i]).src = ('http://openweathermap.org/img/wn/' + (data['daily'][i]['weather'][0]['icon']).substring(0, 2) + "d" + '@2x.png');
                    document.getElementById('desc' + [i]).innerHTML = data['daily'][i]['weather'][0]['description'];
                    document.getElementById('temp' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['day']) + "°";
                    document.getElementById('min' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['min']) + "°";
                    document.getElementById('max' + [i]).innerHTML = Math.round(data['daily'][i]['temp']['max']) + "°";

                    console.log('============================');
                    document.getElementById('display').style.visibility = "visible";
                    document.getElementById('name').innerHTML = inputCity;


                }
            })

    }
}

document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById('inputCity');
    input.addEventListener("keydown", (e) => {
        if (e.keyCode === 13) {
            event.preventDefault();
            searchCity(e.target.value);
            input.value = "";
        }
    })

    const locationButton = document.getElementById('localization');
    locationButton.addEventListener('click', getLocation);

    const searchButton = document.getElementById('search');
    searchButton.addEventListener('click', searchCity);
});